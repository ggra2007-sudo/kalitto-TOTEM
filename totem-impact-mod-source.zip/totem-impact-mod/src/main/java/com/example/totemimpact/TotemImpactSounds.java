package com.example.totemimpact;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class TotemImpactSounds {
    public static final Identifier IMPACT_ID = Identifier.of("totemimpact", "impact");
    public static final SoundEvent IMPACT = SoundEvent.of(IMPACT_ID);
    private TotemImpactSounds() {}
    public static void register() { Registry.register(Registries.SOUND_EVENT, IMPACT_ID, IMPACT); }
}
