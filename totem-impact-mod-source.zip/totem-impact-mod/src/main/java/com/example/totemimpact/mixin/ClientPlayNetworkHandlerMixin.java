package com.example.totemimpact.mixin;

import com.example.totemimpact.TotemImpactClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Inject;
import org.spongepowered.asm.mixin.At;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityStatus", at = @At("HEAD"))
    private void totemImpact$onEntityStatus(EntityStatusS2CPacket packet, CallbackInfo ci) {
        TotemImpactClient.trigger(packet, MinecraftClient.getInstance());
    }
}
