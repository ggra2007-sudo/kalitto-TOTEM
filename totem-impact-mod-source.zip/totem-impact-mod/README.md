# Totem Impact (Fabric client mod)

Client-side visual + audio burst when the server sends the Totem activation entity-status event (status byte 35).

## Effect
- Gold-white particle burst and circular sparks
- End-rod/firework ring around the player
- Custom bass/crack impact sound plus a vanilla explosion accent

## Target
Minecraft Java 1.21.11, Java 21, Fabric Loader.

## Build
1. Install Java 21 and Gradle 8.14 or newer.
2. Open a terminal in this project directory.
3. Run `gradle build`.
4. The compiled mod should be output to `build/libs/totem-impact-1.0.0.jar`.
5. Place the JAR in the `mods` folder of a Minecraft profile running Minecraft 1.21.11 with Fabric Loader.

Fabric API is not required by this project.

**Status:** Source project only. It has not been compiled or tested in-game. The build environment used to create this ZIP did not have Gradle installed and could not reach the Gradle download host, so no installable JAR is included.
