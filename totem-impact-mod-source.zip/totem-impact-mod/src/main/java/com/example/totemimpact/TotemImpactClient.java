package com.example.totemimpact;


import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

public class TotemImpactClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() { TotemImpactSounds.register(); }

    public static void trigger(EntityStatusS2CPacket packet, MinecraftClient client) {
        if (client.world == null || packet.getStatus() != 35) return;
        Entity entity = packet.getEntity(client.world);
        if (!(entity instanceof PlayerEntity player)) return;
        Vec3d p = player.getPos().add(0, 0.15, 0);
        client.world.playSound(client.player, p.x, p.y, p.z, TotemImpactSounds.IMPACT,
                SoundCategory.PLAYERS, 1.25f, 0.92f);
        client.world.playSound(client.player, p.x, p.y, p.z, SoundEvents.ENTITY_GENERIC_EXPLODE,
                SoundCategory.PLAYERS, 0.42f, 1.4f);
        // Expanding-looking horizontal ring, bright gold sparks.
        for (int i = 0; i < 64; i++) {
            double a = (Math.PI * 2 * i) / 64.0;
            double x = Math.cos(a), z = Math.sin(a);
            client.world.addParticle(ParticleTypes.END_ROD, p.x + x * 1.45, p.y + 0.1, p.z + z * 1.45,
                    x * 0.12, 0.07, z * 0.12);
            client.world.addParticle(ParticleTypes.FIREWORK, p.x + x * 0.9, p.y + 0.1, p.z + z * 0.9,
                    x * 0.09, 0.05, z * 0.09);
        }
        for (int i = 0; i < 40; i++) {
            double a = Math.random() * Math.PI * 2;
            double speed = 0.15 + Math.random() * 0.4;
            client.world.addParticle(ParticleTypes.TOTEM, p.x, p.y + 0.5, p.z,
                    Math.cos(a) * speed, 0.1 + Math.random() * 0.35, Math.sin(a) * speed);
            client.world.addParticle(ParticleTypes.CRIT, p.x, p.y + 0.35, p.z,
                    Math.cos(a) * speed * 0.7, 0.12, Math.sin(a) * speed * 0.7);
        }
        for (int i = 0; i < 24; i++) {
            double a = (Math.PI * 2 * i) / 24.0;
            client.world.addParticle(ParticleTypes.FLAME, p.x + Math.cos(a) * 0.55, p.y + 0.95,
                    p.z + Math.sin(a) * 0.55, Math.cos(a) * 0.04, 0.02, Math.sin(a) * 0.04);
        }
    }
}
